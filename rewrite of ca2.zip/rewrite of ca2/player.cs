﻿using System;
using System.Numerics;
using System.Windows;
using System.Xml.Schema;

public class Player
{
    public string Name { get; set; }
    public string ResultRecord { get; set; }
    public int Rating => CalculatePoints();

    public Player(string name, string resultRecord)
    {
        Name = name;
        ResultRecord = resultRecord;

    }
    public override string ToString()
    {
        return $"{Name} - {ResultRecord} - {Rating}";
    }

    public int CalculatePoints()
    {
        int total = 0;

        foreach (char c in ResultRecord)
        {
            if (c == 'W')
            {
                total += 3;
            }
            else if (c == 'D')
            {
                total += 1;
            }
            else
            {
                total += 0;
            }
        }



        return total;
    }
    public int CalculateS()
    {
        int n = Rating;
        if ( n >= 1 && n < 6)
        {
            n = 1;
        }
       else if ( n >= 6 && n < 11)
        {
         n = 2;
        }
        else if (n>12)
        {
         n = 3;
        }
        return n;
    }
}
