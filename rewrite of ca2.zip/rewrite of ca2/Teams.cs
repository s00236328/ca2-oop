﻿using System;
using System.Collections.Generic;
using System.Numerics;

public class Team:IComparable<Team>
{
    public string Name { get; set; }
    
    public List<Player> Players { get; set; }
    public int Rating => CalculateTeamRating();

    public Team(string name, List<Player> players)
    {
        Name = name;
        Players = players;
    }

    // Implement the IComparable<T> interface
    public int CompareTo(Team other)
    {
        // Compare teams based on their ratings
        return other.Rating.CompareTo(this.Rating);
    }

    public override string ToString()
    {
        return $"{Name} - {Rating}";
    }
    public int CalculateTeamRating()
    {
        int totalRating = 0;

        foreach (var player in Players)
        {
            totalRating += player.Rating;
        }

        return totalRating;
    }
}
