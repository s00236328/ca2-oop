﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace rewrite_of_ca2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    ///  // French players

    public partial class MainWindow : Window
    {

        List<Team> teams = new List<Team>();
        public MainWindow()
        {
            InitializeComponent();
            GetData();
        }

        public void GetData()
        {
            //FRENCH BASTARDS
            Player p1 = new Player("Marie", "WWDDL") ;
            Player p2 = new Player("Claude", "DDDLW");
            Player p3 = new Player("Antoine", "LWDLW");
            Team t1 = new Team("France", new List<Player> { p1, p2, p3 });
            // Italian Players
            Player p4 = new Player("Marco", "WWDLL");
            Player p5 = new Player("Giovanni", "LLLLD");
            Player p6 = new Player("Valentina", "DLWWW");
            Team t2 = new Team("Italy", new List<Player> { p4, p5, p6 });
            // Spanish Players
            Player p7 = new Player("Maria", "WWWWW");
            Player p8 = new Player("Jose", "LLLLL");
            Player p9 = new Player("Pablo", "DDDDD");
            Team t3 = new Team("Spanish", new List<Player> { p7, p8, p9 });

            teams.Add(t1);
            teams.Add(t2);
            teams.Add(t3);
            LBXTeams.ItemsSource = teams;
            teams.Sort();
        }
       
      

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
        private void LBXTeams_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Team? chosen = LBXTeams.SelectedItem as Team;

            LBXPlayers.ItemsSource = chosen?.Players;
        }

        private void BTNdraw_Click(object sender, RoutedEventArgs e)
        {

            Player? player = LBXPlayers.SelectedItem as Player;

            if (player == null)
            {
                return;
            }

            player.ResultRecord = player.ResultRecord.Remove(0, 1);
            player.ResultRecord += "D";


            // Refresh the ListBox without clearing the existing ItemsSource
            LBXPlayers.Items.Refresh();
            LBXTeams.Items.Refresh();
            teams.Sort();
            Stars(player);
        }

        private void BTNloss_Click(object sender, RoutedEventArgs e)
        {
            Player? player = LBXPlayers.SelectedItem as Player;

            if (player == null)
            {
                return;
            }

            player.ResultRecord = player.ResultRecord.Remove(0, 1);
            player.ResultRecord += "L";

            LBXPlayers.Items.Refresh();
            LBXTeams.Items.Refresh();
            teams.Sort();
            Stars(player);
        }

        private void BTNwin_Click(object sender, RoutedEventArgs e)
        {
            Player? player = LBXPlayers.SelectedItem as Player;

            if (player == null)
            {
                return;
            }

            player.ResultRecord = player.ResultRecord.Remove(0, 1);
            player.ResultRecord += "W";


            LBXPlayers.Items.Refresh();
            LBXTeams.Items.Refresh();
            teams.Sort();
            Stars(player);
        }

        private void LBXPlayers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Player? player = LBXPlayers.SelectedItem as Player;

            Stars(player);
        }
        private void Stars(Player? player)
        {
            int? Stars = player?.CalculateS();
            string StarOutline= "starsolid.png";
            string StarSolid = "staroutline.png";
            if (Stars >= 1)
                star1.Source = new BitmapImage(new Uri(StarOutline, UriKind.Relative));
            else star1.Source = new BitmapImage(new Uri (StarSolid, UriKind.Relative));

            if (Stars >= 2)
                star2.Source = new BitmapImage(new Uri(StarOutline, UriKind.Relative));
            else star2.Source = new BitmapImage(new Uri(StarSolid, UriKind.Relative));

            if (Stars == 3)
                star3.Source = new BitmapImage(new Uri( StarOutline, UriKind.Relative));
            else star3.Source = new BitmapImage(new Uri(StarSolid, UriKind.Relative));

        }
    }

}
